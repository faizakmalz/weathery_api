from pydantic import BaseModel

class ForecastBase(BaseModel):
    city_id: int
    date: str
    weather_description: str
    temperature: int

class ForecastCreate(ForecastBase):
    pass

class ForecastResponse(ForecastBase):
    id: int

class Config:
    from_attributes = True
